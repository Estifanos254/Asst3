import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * A basic implementation of a doubly linked list with various methods to add, remove, and retrieve elements.
 * @param <T> the type of the elements in the list
 */

public class BasicDoubleLinkedList<T> implements Iterable<T> {
	/**
     * The head of the list
     */

    protected Node head; 
    // The tail of the list
    protected Node tail;
    protected int size;

    public BasicDoubleLinkedList() {
        head = null;
        tail = null;
        size = 0;
    }
    
    @Override
	public ListIterator<T> iterator() {
		return new DoubleLinkedListIterator();
	}

    public int getSize() {
        return size;
    }

    public void addToEnd(T data) {
        Node node = new Node(data);
        if (tail == null) {
            head = node;
            tail = node;
        } else {
            tail.next = node;
            node.prev = tail;
            tail = node;
        }
        size++;
    }
    /**
     * Adds an element to the front of the list.
     * @param data the element to add
     */
    public void addToFront(T data) {
        Node node = new Node(data);
        if (head == null) {
            head = node;
            tail = node;
        } else {
            head.prev = node;
            node.next = head;
            head = node;
        }
        size++;
    }

    public T getFirst() {
        if (head == null) {
            return null;
        } else {
            return head.data;
        }
    }

    public T getLast() {
        if (tail == null) {
            return null;
        } else {
            return tail.data;
        }
    }

    public Node remove(T targetData, Comparator<T> comparator) {
    	
        Node currentNode = head;
        while (currentNode != null) {
            if (comparator.compare(targetData, currentNode.data) == 0) {
                if (currentNode == head) {
                    head = head.next;
                    if (head != null) {
                        head.prev = null;
                    }
                } else if (currentNode == tail) {
                    tail = tail.prev;
                    if (tail != null) {
                        tail.next = null;
                    }
                } else {
                    currentNode.prev.next = currentNode.next;
                    currentNode.next.prev = currentNode.prev;
                }
                size--;
                return currentNode;
            }
            currentNode = currentNode.next;
        }
        return null;
    }

    public T retrieveFirstElement() {
        if (head == null) {
            return null;
        } else {
            T data = head.data;
            head = head.next;
            if (head != null) {
                head.prev = null;
            } else {
                tail = null;
            }
            size--;
            return data;
        }
    }

    public T retrieveLastElement() {
        if (tail == null) {
            return null;
        } else {
            T data = tail.data;
            tail = tail.prev;
            if (tail != null) {
                tail.next = null;
            } else {
                head = null;
            }
            size--;
            return data;
        }
    }

    public ArrayList<T> toArrayList() {
        ArrayList<T> list = new ArrayList<>();
        Node currentNode = head;
        while (currentNode != null) {
            list.add(currentNode.data);
            currentNode = currentNode.next;
        }
        return list;
    }

    protected class Node {
        protected T data;
        protected Node prev;
        protected Node next;

        protected Node(T data) {
            this.data = data;
            prev = null;
            next = null;
        }
    }

    protected class DoubleLinkedListIterator implements ListIterator<T>{
        
        private Node current = head;
        private Node previous = null;
        
        public boolean hasNext() {
            return current != null;
        }
        
        
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException("No more elements");
            }
            T data = current.data;
            previous = current;
            current = current.next;
            return data;// 
        }
        
        
        public void remove() throws UnsupportedOperationException{
        	throw new UnsupportedOperationException();
 	    }

		@Override
		public boolean hasPrevious() {
			return previous != null;
		}

		@Override
		public T previous() {
			if (!hasPrevious()) {
                throw new NoSuchElementException("No more elements");
            }
            current = previous;
            previous = current.prev;
            T data = current.data;
            return data;
		}

		@Override
		public int nextIndex() throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
 	    }

		@Override
		public int previousIndex() throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
 	    }

		@Override
		public void set(T e) throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
 	    }

		@Override
		public void add(T e) throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
 	    }
    }


}