/*
 * @author Estifanos Kebebew
 */
import java.util.Comparator;
import java.util.ListIterator;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> {
	
	private Comparator<T> comparator;
	
	public SortedDoubleLinkedList (Comparator<T> compareableObject) {
		super();
		this.comparator = compareableObject;
	}

	public void add(T data) {
		Node newNode = new Node(data);
        if (size == 0) {
            head = newNode;
            tail = newNode;
        } else if (comparator.compare(head.data, data) >= 0) {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        } else if (comparator.compare(tail.data, data) <= 0) {
            newNode.prev = tail;
            tail.next = newNode;
            tail = newNode;
        } else {
            Node current = head.next;
            while (current != null && comparator.compare(current.data, data) <= 0) {
                current = current.next;
            }
            current.prev.next = newNode;
            newNode.prev = current.prev;
            newNode.next = current;
            current.prev = newNode;
        }
        size++;
	}
	
	@Override
	public ListIterator<T> iterator() {
		return super.iterator();
	}

     
	 @Override
	 public void addToEnd(T data) throws UnsupportedOperationException {
		    throw new UnsupportedOperationException("Invalid operation for sorted list");
		}


	@Override
	public void addToFront(T data) throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}

	@Override
	public BasicDoubleLinkedList<T>.Node remove(T targetData, Comparator<T> comparator) {
		return super.remove(targetData, comparator);
	}
}